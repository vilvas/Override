jQuery(document).ready(function($){

/*==========================================
** Color Picker 3.5+
============================================*/
// Add Color Picker to all inputs that have 'color-field' class
$(function() {
   $('.color-picker-field').wpColorPicker();
});
    
});

