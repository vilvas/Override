jQuery(document).ready(function($){

/*======================================
** Overwite or ADD Classes
======================================*/

$('#login').addClass('row');
$('#login').css("width", "100%")
$('#loginform').addClass('columns medium-7 medium-centered');
$('#login_error').addClass('columns medium-7 medium-centered');
$('.message').addClass('columns medium-7 medium-centered');
$('#registerform').addClass('columns medium-7 medium-centered');

});

